import {calculate, Field, Move, Pokemon} from '../index';

describe('Gen 9 explicit current types', () => {
  const attacker = () => new Pokemon(9, 'Mew', {level: 50});
  const damage = (defender: Pokemon, move = 'Flamethrower', source = attacker(), field?: Field) =>
    calculate(9, source, defender, new Move(9, move), field).damage;

  test('keeps species data separate and clones the supplied type state', () => {
    const p = new Pokemon(9, 'Charizard', {
      typeOverrides: ['Electric', 'Psychic'], addedType: 'Ghost',
    });
    expect(p.species.types).toEqual(['Fire', 'Flying']);
    expect(p.getTypes()).toEqual(['Electric', 'Psychic', 'Ghost']);
    expect(p.clone().getTypes()).toEqual(p.getTypes());
    expect(p.clone().typeOverrides).not.toBe(p.typeOverrides);
    expect(p.hasType('Ghost')).toBe(true);
    expect(p.hasOriginalType('Ghost')).toBe(true);
  });

  test('single type replaces both original types', () => {
    const p = new Pokemon(9, 'Charizard', {typeOverrides: ['Psychic']});
    expect(p.types).toEqual(['Psychic']);
    expect(p.hasType('Flying', 'Fire')).toBe(false);
  });

  test('third type cancels weakness and resistance before damage rounding', () => {
    const p = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Normal', 'Water'], addedType: 'Grass',
    });
    expect(damage(p)).toEqual(damage(new Pokemon(9, 'Mew', {level: 50})));
  });

  test('third type supplies the eighth-fold weakness', () => {
    const p = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Bug', 'Steel'], addedType: 'Grass',
    });
    const dual = damage(new Pokemon(9, 'Mew', {level: 50, typeOverrides: ['Bug', 'Steel']}));
    expect(damage(p)).toEqual((dual as number[]).map(roll => roll * 2));
  });

  test('added Ghost supplies immunity, with Scrappy and Ring Target bypasses', () => {
    const p = new Pokemon(9, 'Mew', {level: 50, addedType: 'Ghost'});
    expect(damage(p, 'Tackle')).toBe(0);
    expect(damage(p, 'Tackle', new Pokemon(9, 'Mew', {level: 50, ability: 'Scrappy'})))
      .toEqual(damage(new Pokemon(9, 'Mew', {level: 50}), 'Tackle'));
    expect(damage(new Pokemon(9, 'Mew', {
      level: 50, addedType: 'Ghost', item: 'Ring Target',
    }), 'Tackle')).toEqual(damage(new Pokemon(9, 'Mew', {level: 50}), 'Tackle'));
  });

  test('added type receives STAB without changing species stats', () => {
    const p = new Pokemon(9, 'Mew', {level: 50, addedType: 'Ghost'});
    const reference = new Pokemon(9, 'Mew', {level: 50, typeOverrides: ['Ghost']});
    expect(damage(new Pokemon(9, 'Mew'), 'Shadow Ball', p))
      .toEqual(damage(new Pokemon(9, 'Mew'), 'Shadow Ball', reference));
  });

  test.each(['Fire', 'Stellar'] as const)('Tera %s clears added type', teraType => {
    const p = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Normal', 'Water'], addedType: 'Grass', teraType,
    });
    const reference = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Normal', 'Water'], teraType,
    });
    expect(p.addedType).toBeUndefined();
    expect(p.clone().addedType).toBeUndefined();
    expect(damage(p)).toEqual(damage(reference));
    expect(damage(new Pokemon(9, 'Mew'), 'Energy Ball', p))
      .toEqual(damage(new Pokemon(9, 'Mew'), 'Energy Ball', reference));
  });

  test('Tera Ghost does not retain added-Ghost double STAB', () => {
    const p = new Pokemon(9, 'Mew', {level: 50, addedType: 'Ghost', teraType: 'Ghost'});
    const reference = new Pokemon(9, 'Mew', {level: 50, teraType: 'Ghost'});
    expect(damage(new Pokemon(9, 'Mew'), 'Shadow Ball', p))
      .toEqual(damage(new Pokemon(9, 'Mew'), 'Shadow Ball', reference));
  });

  test('Freeze-Dry includes the third weakness and multihit rolls remain typed', () => {
    const p = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Water', 'Flying'], addedType: 'Grass',
    });
    const dual = damage(new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Water', 'Flying'],
    }), 'Freeze-Dry');
    expect(damage(p, 'Freeze-Dry')).toEqual((dual as number[]).map(roll => roll * 2));
    const ghost = new Pokemon(9, 'Mew', {addedType: 'Ghost'});
    expect(damage(ghost, 'Double Slap')).toBe(0);
  });

  test('Iron Ball grounding retains the other types with added Grass', () => {
    const p = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Water', 'Flying'], addedType: 'Grass', item: 'Iron Ball',
    });
    const reference = new Pokemon(9, 'Mew', {
      level: 50, typeOverrides: ['Water', 'Grass'], item: 'Iron Ball',
    });
    expect(damage(p, 'Earthquake')).toEqual(damage(reference, 'Earthquake'));
    expect(damage(new Pokemon(9, 'Mew', {
      typeOverrides: ['Water', 'Flying'], addedType: 'Grass', item: 'Iron Ball', ability: 'Klutz',
    }), 'Earthquake')).toBe(0);
  });

  test('Synchronoise can match only the added type', () => {
    const target = new Pokemon(9, 'Gengar');
    expect(damage(target, 'Synchronoise', new Pokemon(9, 'Mew'))).toBe(0);
    expect(damage(target, 'Synchronoise', new Pokemon(9, 'Mew', {addedType: 'Ghost'})))
      .not.toBe(0);
  });

  test('manual type state takes precedence over automatic Forecast inference', () => {
    const field = new Field({weather: 'Sun'});
    const p = new Pokemon(9, 'Castform', {typeOverrides: ['Electric']});
    const reference = new Pokemon(9, 'Castform', {
      typeOverrides: ['Electric'], ability: 'Pressure',
    });
    expect(damage(p, 'Energy Ball', attacker(), field))
      .toEqual(damage(reference, 'Energy Ball', attacker(), field));
  });

  test('rejects unsupported generations, Stellar, and duplicate base types', () => {
    expect(() => new Pokemon(8, 'Mew', {addedType: 'Ghost'})).toThrow('Gen 9');
    expect(() => new Pokemon(9, 'Mew', {typeOverrides: ['Stellar']})).toThrow('ordinary types');
    expect(() => new Pokemon(9, 'Mew', {typeOverrides: ['Ghost', 'Ghost']})).toThrow('distinct');
    expect(new Pokemon(9, 'Gengar', {addedType: 'Ghost'}).getTypes()).toEqual(['Ghost', 'Poison']);
  });
});
